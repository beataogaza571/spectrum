<?php
$botToken = "6856580545:AAEa800tdjD6ZM6jmLNyTW9kN_tSD8thamE";
$chatId = "1001761886";

?>